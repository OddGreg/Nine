<?php namespace Nine\Sql\MySQL;

/**
 * Copyright (C) 2015 David Young
 *
 * Builds a select query
 */

use Nine\Sql\SelectQuery as BaseSelectQuery;

class SelectQuery extends BaseSelectQuery
{
    // Don't do anything
}
