<?php namespace Nine\Sql\MySQL;

/**
 * Copyright (C) 2015 David Young
 *
 * Builds an update query
 */

use Nine\Sql\UpdateQuery as BaseUpdateQuery;

class UpdateQuery extends BaseUpdateQuery
{
    // Don't do anything
}
