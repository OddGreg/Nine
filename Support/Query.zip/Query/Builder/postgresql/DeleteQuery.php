<?php namespace Nine\Sql\PostgreSQL;

/**
 * Copyright (C) 2015 David Young
 *
 * Builds a delete query
 */

use Nine\Sql\DeleteQuery as BaseDeleteQuery;

class DeleteQuery extends BaseDeleteQuery
{
    // Don't do anything
}
